<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'iUHgs7oMLSQR3cCGw5uMrWiRI384cuU9/geKxAo3sPtQnnpPT8ROroWxt4WKOUj6uGKdcoumI1xH7dlOLZWivQ==');
define('SECURE_AUTH_KEY',  'qtl7UWI5ZYyZrb77n1rs7y5KyQWR6nL6j+J1FFsGS3GVFOzwr3kde2mZvuLTba9BtHDUz96uYCsZ4JlDI+FBtA==');
define('LOGGED_IN_KEY',    'B8/2jpNBI/+nH51YrRazSr8sYzbwxCaTFam2OZzAGDvGhvQHsKNg7peUDowQvkDSzBNsINuPe3NfUadoJ5wa7w==');
define('NONCE_KEY',        '5ADcPWDvRTwZz/pqYF2p4YuZxD1Dj9i3dTVTHNhzhlJ/YOtDZx+7WzV1JtnGsmM30/yEx4BmoVAXRwHilir7QQ==');
define('AUTH_SALT',        'pDZ9+i37r7UbhtUfPXUXTZQ2BmgcbvaY3jmg00h2cPG0uKwtvA7r1SWzXPm9YW64WPV4fxZ6aiQ8Lt5pX5jR+w==');
define('SECURE_AUTH_SALT', 'jmcvIof3k67pDaDn1unaWhkbJ+s3wz9uPN2Jbl5X1JUt75cUsJmLjsc8EBiT/5bWWOLF0D5N8uQnuNXCwjgOsA==');
define('LOGGED_IN_SALT',   'lNMXxqwCAFFSbWRzkGL7wMytWP9P8PYU6sE916nAIQbR65g6UMssPIcGEX+K0o/iFRmbslvMU+XSf3YuI+O41Q==');
define('NONCE_SALT',       'HmQII3YQ+T0hV8rLydIxMXZERaEYqZiA1QCw5QYxVsylPpEvnmZQUv7t2y08HlgKz8FS2f2tdoE1hJIpIDbCFg==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
